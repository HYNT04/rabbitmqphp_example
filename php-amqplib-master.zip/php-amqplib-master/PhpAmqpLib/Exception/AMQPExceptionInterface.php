<?php

namespace PhpAmqpLib\Exception;

use Throwable;

interface AMQPExceptionInterface extends Throwable
{
}
