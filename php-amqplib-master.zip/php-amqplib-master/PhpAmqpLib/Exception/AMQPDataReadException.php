<?php

namespace PhpAmqpLib\Exception;

class AMQPDataReadException extends AMQPRuntimeException
{
}
